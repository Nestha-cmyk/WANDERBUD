# WANDERBUD — Phone-friendly static starter

This version is prepared for static hosting (for example Cloudflare Pages). It does not require Node.js or AI credits to publish.

## Publish from Android
1. Download and extract `WANDERBUD-phone-static.zip` on your phone.
2. Open https://dash.cloudflare.com/ and create/sign in to a free account.
3. Open **Workers & Pages** → **Create** → **Pages** → **Upload assets** (the wording may vary).
4. Upload the extracted website files: `index.html`, `styles.css`, `app.js`, `icon.svg`, `manifest.webmanifest`, and `sw.js`. If the upload screen accepts a ZIP, upload this ZIP; otherwise select the extracted files/folder.
5. Deploy. Cloudflare will give you a public `*.pages.dev` URL. Open it on your phone or PC.

## What works in this static version
- Responsive frontend and navigation
- Sample destination browsing, search/filter, details
- Saved places, journey planner, garage, quests/XP/ranks, atlas, journal
- Demo Buddy replies
- Theme toggle and localStorage persistence in the same browser

## Limitations
- The `/api/destinations` request expects a backend and will quietly fall back to built-in sample data on static hosting.
- No accounts, shared data across devices, persistent server database, live AI, GPS tracking, real-time chat, live location, or verified navigation.
- Browser storage is local to the browser/device.
- Service worker/PWA installation depends on HTTPS and browser support.

## Safety
Do not interact with the app while riding. Location sharing should be opt-in and private by default.
